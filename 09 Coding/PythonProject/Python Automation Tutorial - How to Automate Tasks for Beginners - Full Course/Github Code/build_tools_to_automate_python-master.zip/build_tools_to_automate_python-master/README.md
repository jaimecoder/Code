# Build Tools to Automate Stuff in Python

6 Amazing Python Projects for Python beginners to build Tools 

Python Libraries that you'd end up using in these projects

* PIL (Pillow)
* requests
* BeautifulSoup
* camelot
* re
* PDFminer 
* gensim (Summarizer) 


Note: Google has changed the way less secure apps are handeld. It's critical for the Email Automation project in the course. I'm exploring possible alternatives for that. 

